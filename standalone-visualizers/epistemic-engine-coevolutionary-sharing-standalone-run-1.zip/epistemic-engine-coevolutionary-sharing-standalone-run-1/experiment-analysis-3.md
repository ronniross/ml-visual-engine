The two log files capture the behavior of the **Epistemic Engine** under two different regimes: **Hoarding** (trophallaxis off) and **Symbiotic** (trophallaxis on). The HTML file contains the full simulation code, which models nodes that consume energy, process cryptographic hashes to crack target codes, and either hoard energy (blocking others) or share it.

### Key Observations

| Metric                | Hoarder Mode                         | Symbiotic Mode                       |
|-----------------------|--------------------------------------|--------------------------------------|
| **Total cracks**      | 31                                   | 74                                   |
| **Starvation deaths** | Many (frequent `☠ starved` events)   | Very few (only 4 observed)           |
| **Node lifespans**    | Short; many die before reaching high levels | Longer; nodes level up more consistently |
| **Network activity**  | Sporadic cracking, often by isolated nodes | Steady stream of cracks, often by the same nodes in succession |

### What the Logs Show

- **Hoarding** (first log): Nodes greedily consume resources. When they reach max energy, they stop moving and block access to food, causing many others to starve. This creates a chaotic environment where only a few nodes survive long enough to crack targets. The total cracks are low, and the network struggles to maintain momentum.

- **Symbiosis** (second log): With trophallaxis enabled, energy-rich nodes automatically transfer energy to nearby starving nodes (`⇄` events). This stabilizes the population, reduces deaths, and allows more nodes to reach higher levels (up to 6). The result is a dramatic increase in overall hashrate and a much higher number of cracked targets—more than double that of hoarding.

### Why It Matters

The simulation illustrates a classic trade‑off: individual greed vs. collective sharing. In the hoarding mode, selfish behavior leads to resource monopolies and frequent collapses. In the symbiotic mode, cooperation ensures that energy circulates, keeping more nodes active and productive. The logs demonstrate that **trophallaxis (energy sharing) significantly boosts the network’s problem‑solving capacity**, as measured by the number of target codes cracked.

If you’d like to explore further, the HTML file lets you run the simulation yourself and adjust parameters like decay rate, trophallaxis range, and cracking probability. The two logs were generated from identical initial conditions but with trophallaxis toggled off/on.